# Leyla Mertoglu — Personal Portfolio

A responsive, interactive, static HTML/CSS/JavaScript portfolio inspired by the high-end, futuristic agency design reference. This is an original implementation, not a copy of the referenced template's source code.

## Open locally
Double-click `index.html` in your browser. An internet connection is only needed for the optional Google Fonts.

## Update your resume
Edit **`content.js`**. Change your intro, about text, experience, leadership roles, projects, skills, honors, and links. To add an experience or project, copy an existing object in the relevant array and edit the fields. The page renders the new entries automatically.

## Publish
Upload all four website files (`index.html`, `styles.css`, `script.js`, `content.js`) together to a static hosting service such as GitHub Pages or Netlify.

## Privacy
The public website intentionally omits the residential address and phone number from the uploaded resume. The contact button uses the email provided in the resume. You can replace that with a dedicated professional email in `content.js`.

## Features
Responsive navigation, animated hero graphic, scroll reveal, progress indicator, interactive project category filters, project detail dialog, reduced-motion accessibility support, and accessible semantic markup.
