// Edit this file to update your living resume. Add items to the arrays below.
window.PORTFOLIO = {
  name: 'Leyla Mertoglu',
  initials: 'LM',
  headline: 'Building ideas. Leading people. Creating impact.',
  intro: 'Student leader, marketing enthusiast, and curious thinker exploring the intersection of business, finance, and technology.',
  email: 'lmertoglu156@gmail.com',
  school: 'Leonia High School',
  graduation: '2027',
  about: 'I am a student leader and athlete driven by curiosity, collaboration, and a desire to make ideas happen. Whether I am leading my senior class, building initiatives through DECA, or exploring brand strategy through a marketing externship, I enjoy turning ambitious thinking into meaningful results.',
  experience: [
    { role: 'Marketing Extern', org: 'Prophet · New York City', date: 'Professional experience', description: 'Contributed to a marketing-focused externship project, gaining exposure to brand strategy and consulting while developing and presenting ideas in a professional environment.', tags: ['Marketing', 'Strategy', 'Consulting'] }
  ],
  leadership: [
    { role: 'Senior Class President', org: 'Student Council', date: '2026–2027', description: 'Lead school events, fundraisers, pep rallies, and student initiatives; collaborate on budgets and school-wide experiences.' },
    { role: 'Vice President', org: 'DECA Chapter', date: 'Current', description: 'Support school-store rebranding, a proposed credit-card payment initiative, DECA Day, guest speakers, and competition preparation.' },
    { role: 'President', org: 'Historians & Democracy Club', date: 'Senior year', description: 'Lead student debates, history and civic engagement events, and fundraising; previously served as vice president.' },
    { role: 'Captain & MVP', org: 'Varsity Tennis', date: 'Current', description: 'First junior appointed captain in the coach’s 60-year career; support teammates and lead by example on and off the court.' },
    { role: 'Vice President', org: 'Service Club', date: 'Current', description: 'Organize volunteer opportunities and community service initiatives.' }
  ],
  projects: [
    { category: 'BUSINESS', title: 'School Store Modernization', description: 'Helped develop a store rebrand and a proposal to introduce credit-card payments, including presenting the initiative for Board of Education approval.', tags: ['DECA', 'Retail', 'Innovation'], detail: 'Worked with fellow DECA leaders on ways to modernize the student store experience. The initiative combined branding, operational thinking, and a proposal for more convenient payments.' },
    { category: 'LEADERSHIP', title: 'Debate Night Fundraiser', description: 'Organized a debate event that raised approximately $400 toward educational trips to Washington, D.C. and Boston.', tags: ['Fundraising', 'Events', 'Civic Engagement'], detail: 'Coordinated a student debate and fundraising initiative through the Historians & Democracy Club to support learning beyond the classroom.' },
    { category: 'MARKETING', title: 'Brand Strategy Externship', description: 'Explored marketing strategy and consulting through a project-based externship at Prophet.', tags: ['Brand Strategy', 'Presentations', 'Research'], detail: 'Collaborated in a professional setting to develop and communicate ideas related to a marketing-focused externship project.' },
    { category: 'COMMUNITY', title: 'Mentorship & Service', description: 'Tutor with RiseED and volunteer with Women in Business and local community initiatives.', tags: ['Mentorship', 'Education', 'Service'], detail: 'Provide individualized reading, writing, and mathematics support through RiseED, alongside mentorship and service initiatives supporting women.' }
  ],
  skills: {
    'Business & strategy': ['Marketing', 'Brand strategy exposure', 'Business presentations', 'Fundraising', 'Event planning'],
    'Leadership & collaboration': ['Public speaking', 'Team leadership', 'Student advocacy', 'Mentorship', 'Community organizing'],
    'Academic interests': ['Economics', 'Finance', 'Technology', 'History', 'Business innovation'],
    'Languages & creativity': ['English', 'Turkish (partial)', 'Tagalog (partial)', 'Violin', 'Painting']
  },
  awards: ['George Eastman Young Leaders Award', 'Varsity Tennis MVP', 'First Team All-League · Tennis (2×)', 'National Honor Society', 'Rho Kappa National Social Studies Honor Society'],
  links: { linkedin: '', github: '' } // Add your public profile URLs here when ready.
};
